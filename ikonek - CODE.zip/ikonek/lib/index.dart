// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/login/login_widget.dart' show LoginWidget;
export '/lessons/lesson1/lesson1_widget.dart' show Lesson1Widget;
export '/lessons/lesson2/lesson2_widget.dart' show Lesson2Widget;
export '/pages/devs/devs_widget.dart' show DevsWidget;
export '/pages/aboutapp/aboutapp_widget.dart' show AboutappWidget;
export '/pages/settings/settings_widget.dart' show SettingsWidget;
export '/lessons/lesson1_quiz/lesson1_quiz_widget.dart' show Lesson1QuizWidget;
export '/pages/quiz_menu/quiz_menu_widget.dart' show QuizMenuWidget;
export '/lessons/lesson2_quiz/lesson2_quiz_widget.dart' show Lesson2QuizWidget;
export '/pages/ai/ai_widget.dart' show AiWidget;
export '/lessons/lesson1quiz2/lesson1quiz2_widget.dart' show Lesson1quiz2Widget;
export '/lessons/lesson1quiz3/lesson1quiz3_widget.dart' show Lesson1quiz3Widget;
export '/lessons/lesson1quiz4/lesson1quiz4_widget.dart' show Lesson1quiz4Widget;
export '/lessons/lesson1quiz5/lesson1quiz5_widget.dart' show Lesson1quiz5Widget;
export '/lessons/lesson2quiz2/lesson2quiz2_widget.dart' show Lesson2quiz2Widget;
export '/lessons/lesson2quiz3/lesson2quiz3_widget.dart' show Lesson2quiz3Widget;
export '/lessons/lesson2quiz4/lesson2quiz4_widget.dart' show Lesson2quiz4Widget;
export '/lessons/lesson2quiz5/lesson2quiz5_widget.dart' show Lesson2quiz5Widget;
export '/answers/correctanswer1/correctanswer1_widget.dart'
    show Correctanswer1Widget;
export '/answers/wrongpage1/wrongpage1_widget.dart' show Wrongpage1Widget;
export '/answers/correctanswer2/correctanswer2_widget.dart'
    show Correctanswer2Widget;
export '/answers/wrongpage2/wrongpage2_widget.dart' show Wrongpage2Widget;
export '/answers/correctanswer3/correctanswer3_widget.dart'
    show Correctanswer3Widget;
export '/answers/wrongpage3/wrongpage3_widget.dart' show Wrongpage3Widget;
export '/answers/correctanswer4/correctanswer4_widget.dart'
    show Correctanswer4Widget;
export '/answers/wrongpage4/wrongpage4_widget.dart' show Wrongpage4Widget;
export '/answers/correctanswer5/correctanswer5_widget.dart'
    show Correctanswer5Widget;
export '/answers/wrongpage5/wrongpage5_widget.dart' show Wrongpage5Widget;
export '/answers/finish1/finish1_widget.dart' show Finish1Widget;
export '/projects/project1/project1_widget.dart' show Project1Widget;
export '/projects/project1_copy/project1_copy_widget.dart'
    show Project1CopyWidget;

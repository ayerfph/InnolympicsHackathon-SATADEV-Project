import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  int _totalScore = 0;
  int get totalScore => _totalScore;
  set totalScore(int value) {
    _totalScore = value;
  }

  String _selectedAnswer = '';
  String get selectedAnswer => _selectedAnswer;
  set selectedAnswer(String value) {
    _selectedAnswer = value;
  }

  String _correctAnswer = '';
  String get correctAnswer => _correctAnswer;
  set correctAnswer(String value) {
    _correctAnswer = value;
  }
}

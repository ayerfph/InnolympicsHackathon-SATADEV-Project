import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'lesson2_widget.dart' show Lesson2Widget;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Lesson2Model extends FlutterFlowModel<Lesson2Widget> {
  ///  Local state fields for this page.

  String dt1 = 'Overview:';

  String dt2 =
      'The Raspberry Pi Pico is a microcontroller board developed by the Raspberry Pi Foundation. It features the powerful RP2040 microcontroller chip, which offers a high level of performance and flexibility for various embedded projects. With its low cost, small form factor, and extensive community support, the Raspberry Pi Pico is ideal for prototyping, education, and DIY electronics projects.';

  String dt3 = 'History:';

  String dt4 =
      'The Raspberry Pi Pico was announced in January 2021 as the first microcontroller board produced by the Raspberry Pi Foundation. It is based on the RP2040 microcontroller chip, which was designed in-house by the Raspberry Pi team. The Raspberry Pi Pico represents a departure from the traditional single-board computers produced by the foundation, focusing instead on the microcontroller market.\n\n- The RP2040 microcontroller chip used in the Raspberry Pi Pico was designed by the Raspberry Pi Foundation and manufactured by the Taiwan Semiconductor Manufacturing Company (TSMC).\n\n- The Raspberry Pi Pico is notable for its flexible I/O capabilities, with 26 multi-function GPIO pins that can be configured for a wide range of tasks.\n\n- The board supports various programming languages, including MicroPython, CircuitPython, and C/C++, making it accessible to both beginners and experienced developers.\n\n- Despite its small size and low cost, the Raspberry Pi Pico offers impressive performance, with a dual-core ARM Cortex-M0+ processor running at 133 MHz and 264 KB of SRAM.';

  String dt5 = 'Sample project can be do:';

  String dt6 =
      'LED Blink: Make an LED blink on and off at regular intervals.\n\nTraffic Light System: Simulate a traffic light using LEDs and a timer.\n\nLight Sensor: Create a circuit that turns an LED on or off based on ambient light levels.\n\nButton Press Counter: Count and display the number of times a button is pressed.\n\nTemperature Sensor: Measure and display the temperature using a thermistor or a digital sensor.\n\nMoisture Sensor: Detect soil moisture levels and light up an LED if the soil is dry.\n\nServo Motor Control: Control the position of a servo motor using a potentiometer.\n\nSound Sensor: Make an LED light up when a certain sound level is detected.\n\nProximity Sensor: Detect objects that are close to a sensor and light up an LED.\n\nSimple Alarm System: Create a basic alarm that sounds when a sensor is triggered.';

  String dt7 = 'How to use it:';

  String dt8 =
      '1. Connect the Raspberry Pi Pico to your computer using a micro-USB cable.\n2. Install the required software development tools, such as Thonny IDE or Visual Studio Code with the Pico extension.\n3. Write your code using your preferred programming language, such as MicroPython or C/C++.\n4. Compile and upload your code to the Raspberry Pi Pico using the appropriate toolchain.\n5. Test your project and experiment with the GPIO pins to interface with external components, such as sensors, LEDs, and displays.\n6. Explore the extensive documentation and community resources available for the Raspberry Pi Pico to learn more about its features and capabilities.';

  String dt9 = 'Finish';

  ///  State fields for stateful widgets in this page.

  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai1;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai2;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai3;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai4;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai5;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai6;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai7;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai8;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai9;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}

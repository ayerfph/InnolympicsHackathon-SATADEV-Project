import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'lesson1_widget.dart' show Lesson1Widget;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Lesson1Model extends FlutterFlowModel<Lesson1Widget> {
  ///  Local state fields for this page.

  String dt1 = 'Overview:';

  String dt2 =
      'The Arduino Uno is a popular microcontroller board used in various electronic projects. It features a simple design, easy-to-use interface, and compatibility with a wide range of sensors and modules. With its versatility and flexibility, the Arduino Uno is suitable for both beginners and advanced users in the field of electronics and programming.\n';

  String dt3 = 'History:';

  String dt4 =
      'The Arduino Uno was introduced in 2010 as the successor to the original Arduino board. It was developed by a group of engineers at the Interaction Design Institute Ivrea (IDII) in Italy. The goal was to create an affordable and easy-to-use platform for prototyping and experimentation in the field of physical computing.\n\n- The name \"Arduino\" comes from a bar in Ivrea, Italy, where the founders of the project used to meet.\n\n- The Arduino Uno is based on the ATmega328 microcontroller, which is manufactured by Atmel (now part of Microchip Technology).\n\n- Arduino Uno boards are open-source hardware, meaning that the design files and software are freely available for anyone to use and modify.\n\n- The Arduino Uno is one of the most popular microcontroller boards in the world, with millions of units sold worldwide.\n';

  String dt5 = 'Sample project can be do:';

  String dt6 =
      'LED Blink: Make an LED blink on and off at regular intervals.\n\nTraffic Light System: Simulate a traffic light using LEDs and a timer.\n\nLight Sensor: Create a circuit that turns an LED on or off based on ambient light levels.\n\nButton Press Counter: Count and display the number of times a button is pressed.\n\nTemperature Sensor: Measure and display the temperature using a thermistor or a digital sensor.\n\nMoisture Sensor: Detect soil moisture levels and light up an LED if the soil is dry.\n\nServo Motor Control: Control the position of a servo motor using a potentiometer.\n\nSound Sensor: Make an LED light up when a certain sound level is detected.\n\nProximity Sensor: Detect objects that are close to a sensor and light up an LED.\n\nSimple Alarm System: Create a basic alarm that sounds when a sensor is triggered.';

  String dt7 = 'How to use it:';

  String dt8 =
      '1. Connect the Arduino Uno to your computer using a USB cable.\n2. Install the Arduino IDE software on your computer.\n3. Open the Arduino IDE and select the appropriate board (Arduino Uno) and port.\n4. Write your code using the Arduino programming language (based on C/C++).\n5. Upload your code to the Arduino Uno board and test your project.\n6. Explore the vast array of sensors and modules compatible with the Arduino Uno to expand its functionality.\n7. Refer to online tutorials and resources to learn more about programming and interfacing with the Arduino Uno.';

  String finish = 'Finish';

  ///  State fields for stateful widgets in this page.

  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai1;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai2;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai3;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai4;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai5;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai6;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai7;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai8;
  // Stores action output result for [Backend Call - API (Gemini Call)] action in Button widget.
  ApiCallResponse? ai9;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}

  /// Action blocks.
  Future<bool?> finishLesson1(
    BuildContext context, {
    required String? donelesson1,
  }) async {
    return null;
  }
}

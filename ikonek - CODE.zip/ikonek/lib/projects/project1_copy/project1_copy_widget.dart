import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'project1_copy_model.dart';
export 'project1_copy_model.dart';

class Project1CopyWidget extends StatefulWidget {
  const Project1CopyWidget({super.key});

  @override
  State<Project1CopyWidget> createState() => _Project1CopyWidgetState();
}

class _Project1CopyWidgetState extends State<Project1CopyWidget>
    with TickerProviderStateMixin {
  late Project1CopyModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Project1CopyModel());

    animationsMap.addAll({
      'iconOnActionTriggerAnimation1': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          TintEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            color: Colors.black,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'textOnPageLoadAnimation1': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 80.0.ms,
            duration: 1000.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'iconOnActionTriggerAnimation2': AnimationInfo(
        trigger: AnimationTrigger.onActionTrigger,
        applyInitialState: true,
        effectsBuilder: () => [
          TintEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 600.0.ms,
            color: Colors.black,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
      'textOnPageLoadAnimation2': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 80.0.ms,
            duration: 1000.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
    });
    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: Color(0xFF367588),
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.safePop();
            },
          ),
          title: Text(
            'IKONEK',
            textAlign: TextAlign.center,
            style: FlutterFlowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Open Sans',
                  color: FlutterFlowTheme.of(context).info,
                  fontSize: 37.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: true,
          elevation: 0.0,
        ),
        body: SafeArea(
          top: true,
          child: Stack(
            children: [
              SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 12.0, 0.0, 0.0),
                      child: Text(
                        'Ultrasonic Sensor',
                        style:
                            FlutterFlowTheme.of(context).displaySmall.override(
                                  fontFamily: 'Inter Tight',
                                  color: Colors.black,
                                  letterSpacing: 0.0,
                                ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: Padding(
                        padding: EdgeInsets.all(10.0),
                        child: Container(
                          width: 350.0,
                          height: 200.0,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8.0),
                            child: Image.asset(
                              'assets/images/Screenshot_2024-03-30_080058.png',
                              width: 300.0,
                              height: 200.0,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 8.0),
                      child: Text(
                        'Overview:',
                        style: FlutterFlowTheme.of(context).bodySmall.override(
                              fontFamily: 'Inter',
                              color: Colors.black,
                              letterSpacing: 0.0,
                            ),
                      ),
                    ),
                    Flexible(
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 0.0, 16.0, 16.0),
                        child: Text(
                          'The Ultrasonic Sensor is a device that measures distance by emitting ultrasonic waves and calculating the time it takes for the waves to bounce back after hitting an object. It is commonly used in various applications such as robotics, distance measurement, and obstacle detection.',
                          textAlign: TextAlign.start,
                          style:
                              FlutterFlowTheme.of(context).labelLarge.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(-1.0, 0.33),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 8.0),
                        child: Text(
                          'History:',
                          style:
                              FlutterFlowTheme.of(context).bodySmall.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Flexible(
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 0.0, 16.0, 16.0),
                        child: Text(
                          'The concept of ultrasonic technology dates back to the early 20th century when scientists began experimenting with ultrasonic waves for various purposes. The first practical application of ultrasonic sensors emerged in the mid-20th century with the development of sonar systems for underwater navigation and detection. Over time, advancements in technology led to the miniaturization and commercialization of ultrasonic sensors for a wide range of applications.',
                          textAlign: TextAlign.start,
                          style:
                              FlutterFlowTheme.of(context).labelLarge.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(-1.0, 0.33),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 8.0),
                        child: Text(
                          'Trivia:',
                          style:
                              FlutterFlowTheme.of(context).bodySmall.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Flexible(
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 0.0, 16.0, 16.0),
                        child: Text(
                          '- Ultrasonic sensors operate beyond the range of human hearing, typically emitting waves with frequencies above 20 kHz.\n\n- Ultrasonic sensors are often used in automated car parking systems to detect the presence of vehicles and guide drivers to available parking spaces.\n\n- Some ultrasonic sensors utilize Doppler Effect to detect motion, allowing them to be used in speed measurement and motion detection applications.',
                          textAlign: TextAlign.start,
                          style:
                              FlutterFlowTheme.of(context).labelLarge.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(-1.0, 0.33),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 8.0),
                        child: Text(
                          'How to Use it?',
                          style:
                              FlutterFlowTheme.of(context).bodySmall.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Flexible(
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 0.0, 16.0, 16.0),
                        child: Text(
                          '1. Connect the Ultrasonic Sensor to the appropriate pins on your microcontroller or development board.\n\n2. Power the sensor and ensure it is properly initialized.\n\n3. Send a trigger signal to the sensor to initiate the measurement process.\nMeasure the duration it takes for the ultrasonic waves to bounce back to the sensor.\n\n4. Calculate the distance based on the time taken and the speed of sound in air (approximately 343 meters per second at room temperature).',
                          textAlign: TextAlign.start,
                          style:
                              FlutterFlowTheme.of(context).labelLarge.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(-1.0, 0.33),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 8.0),
                        child: Text(
                          'How to Code?',
                          style:
                              FlutterFlowTheme.of(context).bodySmall.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Flexible(
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 0.0, 16.0, 16.0),
                        child: Text(
                          'These codes demonstrate how to interface with an Ultrasonic Sensor using Arduino and Python on a Raspberry Pi. They perform the task of measuring distance based on the time taken for ultrasonic waves to bounce back from an object',
                          textAlign: TextAlign.start,
                          style:
                              FlutterFlowTheme.of(context).labelLarge.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(-1.0, 0.33),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 8.0),
                        child: Text(
                          'For Arduino:',
                          style:
                              FlutterFlowTheme.of(context).bodySmall.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: Padding(
                        padding: EdgeInsets.all(12.0),
                        child: Container(
                          width: 350.0,
                          height: 650.0,
                          decoration: BoxDecoration(
                            color: Color(0xFF9D9696),
                          ),
                          child: Align(
                            alignment: AlignmentDirectional(-1.0, 0.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Align(
                                  alignment: AlignmentDirectional(0.0, -1.0),
                                  child: Padding(
                                    padding: EdgeInsets.all(6.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: 332.0,
                                          height: 31.0,
                                          decoration: BoxDecoration(
                                            color: Color(0xFF9D9696),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Align(
                                                alignment: AlignmentDirectional(
                                                    -1.0, 0.0),
                                                child: Padding(
                                                  padding: EdgeInsets.all(4.0),
                                                  child: Text(
                                                    'cpp',
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Inter',
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .info,
                                                          letterSpacing: 0.0,
                                                        ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: 273.0,
                                                height: 100.0,
                                                decoration: BoxDecoration(
                                                  color: Color(0xFF9D9696),
                                                ),
                                              ),
                                              InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onTap: () async {
                                                  await Clipboard.setData(
                                                      ClipboardData(
                                                          text:
                                                              'const int trigPin = 9; // Define the trigger pin connected to the Ultrasonic Sensor const int echoPin = 10; // Define the echo pin connected to the Ultrasonic Sensor  void setup() {   Serial.begin(9600); // Initialize serial communication   pinMode(trigPin, OUTPUT); // Set trigPin as an output   pinMode(echoPin, INPUT); // Set echoPin as an input }  void loop() {   long duration, distance; // Define variables to store duration and distance   digitalWrite(trigPin, LOW); // Ensure the trigger pin is low   delayMicroseconds(2); // Wait for stabilization   digitalWrite(trigPin, HIGH); // Send a pulse to the trigger pin   delayMicroseconds(10); // Wait for the pulse to propagate   digitalWrite(trigPin, LOW); // Turn off the pulse    duration = pulseIn(echoPin, HIGH); // Measure the duration of the echo pulse   distance = duration * 0.034 / 2; // Calculate distance based on the duration   Serial.print(\"Distance: \"); // Print distance to serial monitor   Serial.println(distance);   delay(1000); // Delay before next measurement }'));
                                                },
                                                child: Icon(
                                                  Icons.content_copy,
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .info,
                                                  size: 24.0,
                                                ),
                                              ).animateOnActionTrigger(
                                                animationsMap[
                                                    'iconOnActionTriggerAnimation1']!,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Container(
                                      width: 343.0,
                                      height: 609.0,
                                      decoration: BoxDecoration(
                                        color: Colors.black,
                                      ),
                                      child: Align(
                                        alignment:
                                            AlignmentDirectional(-1.0, -1.0),
                                        child: Padding(
                                          padding: EdgeInsets.all(6.0),
                                          child: Text(
                                            'const int trigPin = 9; // Define the trigger pin connected to the Ultrasonic Sensor\nconst int echoPin = 10; // Define the echo pin connected to the Ultrasonic Sensor\n\nvoid setup() {\n  Serial.begin(9600); // Initialize serial communication\n  pinMode(trigPin, OUTPUT); // Set trigPin as an output\n  pinMode(echoPin, INPUT); // Set echoPin as an input\n}\n\nvoid loop() {\n  long duration, distance; // Define variables to store duration and distance\n  digitalWrite(trigPin, LOW); // Ensure the trigger pin is low\n  delayMicroseconds(2); // Wait for stabilization\n  digitalWrite(trigPin, HIGH); // Send a pulse to the trigger pin\n  delayMicroseconds(10); // Wait for the pulse to propagate\n  digitalWrite(trigPin, LOW); // Turn off the pulse\n\n  duration = pulseIn(echoPin, HIGH); // Measure the duration of the echo pulse\n  distance = duration * 0.034 / 2; // Calculate distance based on the duration\n  Serial.print(\"Distance: \"); // Print distance to serial monitor\n  Serial.println(distance);\n  delay(1000); // Delay before next measurement\n}\n',
                                            textAlign: TextAlign.start,
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .info,
                                                  letterSpacing: 0.0,
                                                ),
                                          ).animateOnPageLoad(animationsMap[
                                              'textOnPageLoadAnimation1']!),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(-1.0, 0.33),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 8.0),
                        child: Text(
                          'Code Explanation:',
                          style:
                              FlutterFlowTheme.of(context).bodySmall.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Flexible(
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 0.0, 16.0, 16.0),
                        child: Text(
                          '1. We start by defining two variables trigPin and echoPin to represent the pins connected to the trigger and echo pins of the ultrasonic sensor, respectively.\n\n2. In the setup() function, we initialize serial communication for debugging purposes and set the trigPin as an output and echoPin as an input.\n\n3. The loop() function runs continuously. Inside the loop, we:\nSet the trigPin low to ensure it is ready for the next measurement.\n\n4. Send a short pulse to the trigPin to trigger the ultrasonic sensor.\n\n5. Measure the duration of the echo pulse using the pulseIn() function, which returns the duration in microseconds.\n\n6. Calculate the distance based on the duration using the formula distance = duration * 0.034 / 2. The factor 0.034 represents the speed of sound in centimeters per microsecond, and we divide by 2 because the sound travels to the object and back.\n\n7. Print the calculated distance to the serial monitor for debugging.\nDelay for 1 second before taking the next measurement.',
                          textAlign: TextAlign.start,
                          style:
                              FlutterFlowTheme.of(context).labelLarge.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(-1.0, 0.33),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 8.0),
                        child: Text(
                          'For Raspberry Pi:',
                          style:
                              FlutterFlowTheme.of(context).bodySmall.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(0.0, 0.0),
                      child: Padding(
                        padding: EdgeInsets.all(12.0),
                        child: Container(
                          width: 350.0,
                          height: 854.0,
                          decoration: BoxDecoration(
                            color: Color(0xFF9D9696),
                          ),
                          child: Align(
                            alignment: AlignmentDirectional(-1.0, 0.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Align(
                                  alignment: AlignmentDirectional(0.0, -1.0),
                                  child: Padding(
                                    padding: EdgeInsets.all(6.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: 332.0,
                                          height: 31.0,
                                          decoration: BoxDecoration(
                                            color: Color(0xFF9D9696),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Align(
                                                alignment: AlignmentDirectional(
                                                    -1.0, 0.0),
                                                child: Padding(
                                                  padding: EdgeInsets.all(4.0),
                                                  child: Text(
                                                    'python',
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Inter',
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .info,
                                                          letterSpacing: 0.0,
                                                        ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: 252.0,
                                                height: 100.0,
                                                decoration: BoxDecoration(
                                                  color: Color(0xFF9D9696),
                                                ),
                                              ),
                                              InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onTap: () async {
                                                  await Clipboard.setData(
                                                      ClipboardData(
                                                          text:
                                                              'import RPi.GPIO as GPIO import time  trigPin = 23 # Define the GPIO pin connected to the trigger pin of the Ultrasonic Sensor echoPin = 24 # Define the GPIO pin connected to the echo pin of the Ultrasonic Sensor  GPIO.setmode(GPIO.BCM) # Set GPIO numbering mode GPIO.setup(trigPin, GPIO.OUT) # Set trigPin as an output GPIO.setup(echoPin, GPIO.IN) # Set echoPin as an input  try:     while True:         GPIO.output(trigPin, False) # Ensure the trigger pin is low         time.sleep(0.5) # Wait for stabilization         GPIO.output(trigPin, True) # Send a pulse to the trigger pin         time.sleep(0.00001) # Wait for the pulse to propagate         GPIO.output(trigPin, False) # Turn off the pulse          while GPIO.input(echoPin) == 0: # Wait for the echo pulse to start             pulse_start = time.time()                      while GPIO.input(echoPin) == 1: # Wait for the echo pulse to end             pulse_end = time.time()                      pulse_duration = pulse_end - pulse_start # Calculate duration of the echo pulse         distance = pulse_duration * 17150 # Calculate distance based on the duration                  print(\"Distance:\", distance, \"cm\") # Print distance         time.sleep(1) # Delay before next measurement  finally:     GPIO.cleanup() # Clean up GPIO on exit'));
                                                },
                                                child: Icon(
                                                  Icons.content_copy,
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .info,
                                                  size: 24.0,
                                                ),
                                              ).animateOnActionTrigger(
                                                animationsMap[
                                                    'iconOnActionTriggerAnimation2']!,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Container(
                                      width: 343.0,
                                      height: 812.0,
                                      decoration: BoxDecoration(
                                        color: Colors.black,
                                      ),
                                      child: Align(
                                        alignment:
                                            AlignmentDirectional(-1.0, -1.0),
                                        child: Padding(
                                          padding: EdgeInsets.all(6.0),
                                          child: Text(
                                            'import RPi.GPIO as GPIO\nimport time\n\ntrigPin = 23 # Define the GPIO pin connected to the trigger pin of the Ultrasonic Sensor\nechoPin = 24 # Define the GPIO pin connected to the echo pin of the Ultrasonic Sensor\n\nGPIO.setmode(GPIO.BCM) # Set GPIO numbering mode\nGPIO.setup(trigPin, GPIO.OUT) # Set trigPin as an output\nGPIO.setup(echoPin, GPIO.IN) # Set echoPin as an input\n\ntry:\n    while True:\n        GPIO.output(trigPin, False) # Ensure the trigger pin is low\n        time.sleep(0.5) # Wait for stabilization\n        GPIO.output(trigPin, True) # Send a pulse to the trigger pin\n        time.sleep(0.00001) # Wait for the pulse to propagate\n        GPIO.output(trigPin, False) # Turn off the pulse\n\n        while GPIO.input(echoPin) == 0: # Wait for the echo pulse to start\n            pulse_start = time.time()\n            \n        while GPIO.input(echoPin) == 1: # Wait for the echo pulse to end\n            pulse_end = time.time()\n            \n        pulse_duration = pulse_end - pulse_start # Calculate duration of the echo pulse\n        distance = pulse_duration * 17150 # Calculate distance based on the duration\n        \n        print(\"Distance:\", distance, \"cm\") # Print distance\n        time.sleep(1) # Delay before next measurement\n\nfinally:\n    GPIO.cleanup() # Clean up GPIO on exit\n',
                                            textAlign: TextAlign.start,
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .info,
                                                  letterSpacing: 0.0,
                                                ),
                                          ).animateOnPageLoad(animationsMap[
                                              'textOnPageLoadAnimation2']!),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Align(
                      alignment: AlignmentDirectional(-1.0, 0.33),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 0.0, 8.0),
                        child: Text(
                          'Code Explanation:',
                          style:
                              FlutterFlowTheme.of(context).bodySmall.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                    Flexible(
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            16.0, 0.0, 16.0, 16.0),
                        child: Text(
                          '1. We import the RPi.GPIO library and the time module for controlling GPIO pins and adding delays, respectively.\n\n2. We define trigPin and echoPin variables to represent the GPIO pins connected to the trigger and echo pins of the ultrasonic sensor, respectively.\n\n3. We set the GPIO numbering mode to BCM and configure the pins as output and input for the trigger and echo pins, respectively.\n\n4. Inside a try block, we continuously:\nSet the trigger pin low to ensure it is ready for the next measurement.\n\n5. Send a short pulse to the trigger pin to trigger the ultrasonic sensor.\n\n6. Measure the duration of the echo pulse by recording the time when the pulse starts (pulse_start) and ends (pulse_end).\n\n7. Calculate the duration of the echo pulse and use it to calculate the distance in centimeters using the formula distance = pulse_duration * 17150 (assuming the speed of sound is approximately 343 meters per second).\n\n8. Print the calculated distance to the console.\n\n9. Delay for 1 second before taking the next measurement.\n\n10. Finally, we clean up the GPIO pins when the program exits using the GPIO.cleanup() function.',
                          textAlign: TextAlign.start,
                          style:
                              FlutterFlowTheme.of(context).labelLarge.override(
                                    fontFamily: 'Inter',
                                    color: Colors.black,
                                    letterSpacing: 0.0,
                                  ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

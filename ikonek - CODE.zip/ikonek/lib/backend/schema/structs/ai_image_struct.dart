// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AiImageStruct extends FFFirebaseStruct {
  AiImageStruct({
    String? status,
    DataStruct? data,
    MetadataStruct? metadata,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _status = status,
        _data = data,
        _metadata = metadata,
        super(firestoreUtilData);

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  set status(String? val) => _status = val;

  bool hasStatus() => _status != null;

  // "data" field.
  DataStruct? _data;
  DataStruct get data => _data ?? DataStruct();
  set data(DataStruct? val) => _data = val;

  void updateData(Function(DataStruct) updateFn) {
    updateFn(_data ??= DataStruct());
  }

  bool hasData() => _data != null;

  // "metadata" field.
  MetadataStruct? _metadata;
  MetadataStruct get metadata => _metadata ?? MetadataStruct();
  set metadata(MetadataStruct? val) => _metadata = val;

  void updateMetadata(Function(MetadataStruct) updateFn) {
    updateFn(_metadata ??= MetadataStruct());
  }

  bool hasMetadata() => _metadata != null;

  static AiImageStruct fromMap(Map<String, dynamic> data) => AiImageStruct(
        status: data['status'] as String?,
        data: data['data'] is DataStruct
            ? data['data']
            : DataStruct.maybeFromMap(data['data']),
        metadata: data['metadata'] is MetadataStruct
            ? data['metadata']
            : MetadataStruct.maybeFromMap(data['metadata']),
      );

  static AiImageStruct? maybeFromMap(dynamic data) =>
      data is Map ? AiImageStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'status': _status,
        'data': _data?.toMap(),
        'metadata': _metadata?.toMap(),
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'status': serializeParam(
          _status,
          ParamType.String,
        ),
        'data': serializeParam(
          _data,
          ParamType.DataStruct,
        ),
        'metadata': serializeParam(
          _metadata,
          ParamType.DataStruct,
        ),
      }.withoutNulls;

  static AiImageStruct fromSerializableMap(Map<String, dynamic> data) =>
      AiImageStruct(
        status: deserializeParam(
          data['status'],
          ParamType.String,
          false,
        ),
        data: deserializeStructParam(
          data['data'],
          ParamType.DataStruct,
          false,
          structBuilder: DataStruct.fromSerializableMap,
        ),
        metadata: deserializeStructParam(
          data['metadata'],
          ParamType.DataStruct,
          false,
          structBuilder: MetadataStruct.fromSerializableMap,
        ),
      );

  @override
  String toString() => 'AiImageStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is AiImageStruct &&
        status == other.status &&
        data == other.data &&
        metadata == other.metadata;
  }

  @override
  int get hashCode => const ListEquality().hash([status, data, metadata]);
}

AiImageStruct createAiImageStruct({
  String? status,
  DataStruct? data,
  MetadataStruct? metadata,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    AiImageStruct(
      status: status,
      data: data ?? (clearUnsetFields ? DataStruct() : null),
      metadata: metadata ?? (clearUnsetFields ? MetadataStruct() : null),
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

AiImageStruct? updateAiImageStruct(
  AiImageStruct? aiImage, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    aiImage
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addAiImageStructData(
  Map<String, dynamic> firestoreData,
  AiImageStruct? aiImage,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (aiImage == null) {
    return;
  }
  if (aiImage.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && aiImage.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final aiImageData = getAiImageFirestoreData(aiImage, forFieldValue);
  final nestedData = aiImageData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = aiImage.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getAiImageFirestoreData(
  AiImageStruct? aiImage, [
  bool forFieldValue = false,
]) {
  if (aiImage == null) {
    return {};
  }
  final firestoreData = mapToFirestore(aiImage.toMap());

  // Handle nested data for "data" field.
  addDataStructData(
    firestoreData,
    aiImage.hasData() ? aiImage.data : null,
    'data',
    forFieldValue,
  );

  // Handle nested data for "metadata" field.
  addMetadataStructData(
    firestoreData,
    aiImage.hasMetadata() ? aiImage.metadata : null,
    'metadata',
    forFieldValue,
  );

  // Add any Firestore field values
  aiImage.firestoreUtilData.fieldValues.forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getAiImageListFirestoreData(
  List<AiImageStruct>? aiImages,
) =>
    aiImages?.map((e) => getAiImageFirestoreData(e, true)).toList() ?? [];

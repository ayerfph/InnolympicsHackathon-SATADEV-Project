// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DataStruct extends FFFirebaseStruct {
  DataStruct({
    String? imageId,
    String? imageTitle,
    String? imageAiDescription,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _imageId = imageId,
        _imageTitle = imageTitle,
        _imageAiDescription = imageAiDescription,
        super(firestoreUtilData);

  // "image_id" field.
  String? _imageId;
  String get imageId => _imageId ?? '';
  set imageId(String? val) => _imageId = val;

  bool hasImageId() => _imageId != null;

  // "image_title" field.
  String? _imageTitle;
  String get imageTitle => _imageTitle ?? '';
  set imageTitle(String? val) => _imageTitle = val;

  bool hasImageTitle() => _imageTitle != null;

  // "image_ai_description" field.
  String? _imageAiDescription;
  String get imageAiDescription => _imageAiDescription ?? '';
  set imageAiDescription(String? val) => _imageAiDescription = val;

  bool hasImageAiDescription() => _imageAiDescription != null;

  static DataStruct fromMap(Map<String, dynamic> data) => DataStruct(
        imageId: data['image_id'] as String?,
        imageTitle: data['image_title'] as String?,
        imageAiDescription: data['image_ai_description'] as String?,
      );

  static DataStruct? maybeFromMap(dynamic data) =>
      data is Map ? DataStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'image_id': _imageId,
        'image_title': _imageTitle,
        'image_ai_description': _imageAiDescription,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'image_id': serializeParam(
          _imageId,
          ParamType.String,
        ),
        'image_title': serializeParam(
          _imageTitle,
          ParamType.String,
        ),
        'image_ai_description': serializeParam(
          _imageAiDescription,
          ParamType.String,
        ),
      }.withoutNulls;

  static DataStruct fromSerializableMap(Map<String, dynamic> data) =>
      DataStruct(
        imageId: deserializeParam(
          data['image_id'],
          ParamType.String,
          false,
        ),
        imageTitle: deserializeParam(
          data['image_title'],
          ParamType.String,
          false,
        ),
        imageAiDescription: deserializeParam(
          data['image_ai_description'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'DataStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is DataStruct &&
        imageId == other.imageId &&
        imageTitle == other.imageTitle &&
        imageAiDescription == other.imageAiDescription;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([imageId, imageTitle, imageAiDescription]);
}

DataStruct createDataStruct({
  String? imageId,
  String? imageTitle,
  String? imageAiDescription,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    DataStruct(
      imageId: imageId,
      imageTitle: imageTitle,
      imageAiDescription: imageAiDescription,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

DataStruct? updateDataStruct(
  DataStruct? data, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    data
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addDataStructData(
  Map<String, dynamic> firestoreData,
  DataStruct? data,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (data == null) {
    return;
  }
  if (data.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields = !forFieldValue && data.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final dataData = getDataFirestoreData(data, forFieldValue);
  final nestedData = dataData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = data.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getDataFirestoreData(
  DataStruct? data, [
  bool forFieldValue = false,
]) {
  if (data == null) {
    return {};
  }
  final firestoreData = mapToFirestore(data.toMap());

  // Add any Firestore field values
  data.firestoreUtilData.fieldValues.forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getDataListFirestoreData(
  List<DataStruct>? datas,
) =>
    datas?.map((e) => getDataFirestoreData(e, true)).toList() ?? [];

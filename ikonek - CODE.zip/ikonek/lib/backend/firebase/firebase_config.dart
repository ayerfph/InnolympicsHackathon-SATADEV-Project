import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAw8i1ote8Ntiw1uiFQT8QMna_CkmLSCxI",
            authDomain: "sata-dev-project.firebaseapp.com",
            projectId: "sata-dev-project",
            storageBucket: "sata-dev-project.firebasestorage.app",
            messagingSenderId: "1042071934139",
            appId: "1:1042071934139:web:b86b4746410bfcf074c59e"));
  } else {
    await Firebase.initializeApp();
  }
}

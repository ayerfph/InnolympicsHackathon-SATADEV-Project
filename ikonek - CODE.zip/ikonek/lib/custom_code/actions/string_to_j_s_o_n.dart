// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'dart:core';

Future<dynamic> stringToJSON(String inputString) async {
  try {
    final regex = RegExp(r'\{.*\}', dotAll: true);
    final match = regex.firstMatch(inputString);

    if (match != null) {
      final jsonString = match.group(0);

      if (jsonString != null) {
        final jsonData = json.decode(jsonString);
        return jsonData;
      } else {
        throw FormatException("No valid JSON found in the string.");
      }
    } else {
      throw FormatException("No JSON object found in the string.");
    }
  } catch (e) {
    print("Error parsing JSON: $e");
    return null;
  }
}
// End custom action code
